package com.example.opencity.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.opencity.R
import androidx.compose.ui.window.Dialog
import com.example.opencity.ui.components.TopBar
import com.example.opencity.ui.components.settings.SettingsAction
import com.example.opencity.ui.components.settings.SettingsDivider
import com.example.opencity.ui.components.settings.SettingsSection
import com.example.opencity.ui.components.settings.SettingsSwitch
import com.example.opencity.ui.components.settings.SettingsSingleFromMultiple
import com.example.opencity.ui.components.settings.SettingsOption
import com.example.opencity.models.enums.DarkModeType
import com.example.opencity.models.enums.MapOrientationMode
import com.example.opencity.storage.AppSettings
import com.example.opencity.storage.Settings
import com.example.opencity.storage.SettingsRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch


@Composable
fun SettingsScreen(
    onManageMarkers: () -> Unit = {},
    onOfflineMaps: () -> Unit = {},
    onAccountSettings: () -> Unit = {},
    onReturn: () -> Unit = {},
    settingsRepo: SettingsRepository
) {
    val scope: CoroutineScope = rememberCoroutineScope()
    val settings by produceState<AppSettings?>(initialValue = null, key1 = settingsRepo) { settingsRepo.settings.collect { value = it } }
    val currentSettings = settings
    if (currentSettings == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        return
    }
    val darkModeType = currentSettings.themeMode
    fun saveDarkModeType(mode: DarkModeType) { scope.launch {
        settingsRepo.setSettingValue(
            Settings.THEME_MODE,
            mode
        ); } }

    var animationsEnabled by rememberSaveable { mutableStateOf(true) }

    var nearbyNotifications by rememberSaveable { mutableStateOf(true) }
    var reportUpdates by rememberSaveable { mutableStateOf(true) }
    var commentNotifications by rememberSaveable { mutableStateOf(true) }
    var highSeverityNotifications by rememberSaveable { mutableStateOf(false) }

    val mapOrientation = currentSettings.mapOrientationMode
    fun saveMapOrientationMode(mode: MapOrientationMode) { scope.launch {
        settingsRepo.setSettingValue(
            Settings.MAP_ORIENTATION_MODE,
            mode
        ) } }

    var heatmapEnabled by rememberSaveable { mutableStateOf(false) }
    var pathTracingEnabled by rememberSaveable { mutableStateOf(false) }

    var showConfirmation by remember { mutableStateOf(false) }
    fun onServerConfiguration() {
        showConfirmation = true
    }

    // Composable for onServerConfiguration
    if (showConfirmation) {
        Dialog(onDismissRequest = { showConfirmation = false }) {
            Surface(
                shape = MaterialTheme.shapes.extraLarge,
                tonalElevation = 6.dp
            ) {
                Column(Modifier.padding(24.dp)) {
                    Text("Change server?", style = MaterialTheme.typography.titleLarge)
                    Spacer(Modifier.height(16.dp))
                    Text("You will be logged out. Your local markers will not be lost.")

                    Spacer(Modifier.height(24.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = { showConfirmation = false }) {
                            Text("Cancel")
                        }
                        TextButton(
                            onClick = {
                                showConfirmation = false
                                // TODO: call onLogOut()
                                scope.launch {
                                    settingsRepo.setSettingValue(
                                        Settings.SERVER_ADDRESS,
                                        ""
                                    ); }
                            }
                        ) {
                            Text("Continue")
                        }
                    }
                }
            }
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        TopBar(tittle = stringResource(R.string.settings_screen_top_bar_title), stringResource(R.string.settings_screen_top_bar_description), true, onReturn)
        Column(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
            LazyColumn(
                contentPadding = PaddingValues(bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    SettingsSection(title = stringResource(R.string.settings_screen_appearance_section)) {
                        SettingsSingleFromMultiple(
                            title = stringResource(R.string.settings_screen_interface_mode_title),
                            description = stringResource(R.string.settings_screen_interface_mode_description),
                            options = listOf(
                                SettingsOption(
                                    value = DarkModeType.AUTO,
                                    title = stringResource(R.string.settings_screen_interface_automatic_title),
                                    description = stringResource(R.string.settings_screen_interface_automatic_description)
                                ),
                                SettingsOption(
                                    value = DarkModeType.LIGHT_MODE,
                                    title = stringResource(R.string.settings_screen_interface_light_mode_title),
                                    description = stringResource(R.string.settings_screen_interface_light_mode_description)
                                ),
                                SettingsOption(
                                    value = DarkModeType.DARK_MODE,
                                    title = stringResource(R.string.settings_screen_interface_dark_mode_title),
                                    description = stringResource(R.string.settings_screen_interface_dark_mode_description))
                            ),
                            selectedValue = darkModeType,
                            onValueSelected = { selected -> saveDarkModeType(selected)}
                        )
                        SettingsDivider()
                        SettingsSwitch(
                            title = stringResource(R.string.settings_screen_animation_switch_title),
                            description = stringResource(R.string.settings_screen_animation_switch_description), //nao sei como meter o \n
                            checked = animationsEnabled,
                            onCheckedChange = { animationsEnabled = it }
                        )
                    }
                }
                item {
                    SettingsSection(title = stringResource(R.string.settings_screen_notifications_section)) {
                        SettingsSwitch(
                            title = stringResource(R.string.settings_screen_notifications_section_nearby_reports_switch_title),
                            description = stringResource(R.string.settings_screen_notifications_section_nearby_reports_switch_description),
                            checked = nearbyNotifications,
                            onCheckedChange = { nearbyNotifications = it }
                        )
                        SettingsDivider()
                        SettingsSwitch(
                            title = stringResource(R.string.settings_screen_notifications_section_report_updates_switch_title),
                            description = stringResource(R.string.settings_screen_notifications_section_report_updates_switch_description),
                            checked = reportUpdates,
                            onCheckedChange = { reportUpdates = it }
                        )
                        SettingsDivider()
                        SettingsSwitch(
                            title = stringResource(R.string.settings_screen_notifications_section_comments_switch_title),
                            description = stringResource(R.string.settings_screen_notifications_section_comments_switch_description),
                            checked = commentNotifications,
                            onCheckedChange = { commentNotifications = it }
                        )
                        SettingsDivider()
                        SettingsSwitch(
                            title = stringResource(R.string.settings_screen_notifications_section_high_severity_reports_switch_title),
                            description = stringResource(R.string.settings_screen_notifications_section_high_severity_reports_switch_description),
                            checked = highSeverityNotifications,
                            onCheckedChange = { highSeverityNotifications = it }
                        )
                    }
                }
                item {
                    SettingsSection(title = stringResource(R.string.settings_screen_map_section)) {
                        SettingsSingleFromMultiple(
                            title = stringResource(R.string. settings_screen_map_section_title),
                            description = stringResource(R.string. settings_screen_map_section_description),
                            options = listOf(
                                SettingsOption(
                                    value = MapOrientationMode.NORTH_UP,
                                    title = stringResource(R.string. settings_screen_map_north_section_title),
                                    description = stringResource(R.string. settings_screen_map_north_section_description)
                                ),
                                SettingsOption(
                                    value = MapOrientationMode.MANUAL_ROTATION,
                                    title = stringResource(R.string. settings_screen_map_manual_section_title),
                                    description = stringResource(R.string. settings_screen_map_manual_section_description)
                                ),
                                SettingsOption(
                                    value = MapOrientationMode.COMPASS,
                                    title = stringResource(R.string. settings_screen_map_compass_section_title),
                                    description = stringResource(R.string. settings_screen_map_compass_section_description)
                                )
                            ),
                            selectedValue = mapOrientation,
                            onValueSelected = { selected -> saveMapOrientationMode(selected) }
                        )
                        SettingsDivider()
                        SettingsSwitch(
                            title = stringResource(R.string. settings_screen_heatmap_section_title),
                            description = stringResource(R.string. settings_screen_heatmap_section_description),
                            checked = heatmapEnabled,
                            onCheckedChange = { heatmapEnabled = it }
                        )
                        SettingsDivider()
                        SettingsSwitch(
                            title = "Path tracing",       // nao traduzi porque vai ser para tirar
                            description = "Show paths and routes on the map",
                            checked = pathTracingEnabled,
                            onCheckedChange = { pathTracingEnabled = it }
                        )
                        SettingsDivider()
                        SettingsAction(
                            title = stringResource(R.string. settings_screen_offline_section_title),
                            description = stringResource(R.string. settings_screen_offline_section_description),
                            buttonText = stringResource(R.string. settings_screen_offline_section_button),
                            onClick = onOfflineMaps
                        )
                        SettingsAction(
                            title = stringResource(R.string. settings_screen_marker_section_title),
                            description = stringResource(R.string. settings_screen_marker_section_description),
                            buttonText = stringResource(R.string. settings_screen_marker_section_button),
                            onClick = onManageMarkers
                        )
                    }
                }
                item {
                    SettingsSection(title = stringResource(R.string. settings_screen_server_section)) {
                        SettingsAction(
                            title = stringResource(R.string. settings_screen_server_change_section_title),
                            description =  stringResource(R.string. settings_screen_server_change_section_description),
                            buttonText =  stringResource(R.string. settings_screen_server_change_section_button),
                            onClick = { onServerConfiguration() }
                        )
                    }
                }
                item {
                    SettingsSection(title  = stringResource(R.string. settings_screen_privacy_section_title)) {
                        SettingsAction(
                            title = stringResource(R.string. settings_screen_privacy_data_management_section_title),
                            description = stringResource(R.string. settings_screen_privacy_data_management_section_description),
                            buttonText = stringResource(R.string. settings_screen_privacy_data_management_section_button),
                            onClick = onAccountSettings
                        )
                    }
                }
            }
        }
    }
}
